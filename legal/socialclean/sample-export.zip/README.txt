Sample data for App Review. All usernames are fictional (prefixed demo_).
Structure matches Instagram's "Download your information" JSON export.
